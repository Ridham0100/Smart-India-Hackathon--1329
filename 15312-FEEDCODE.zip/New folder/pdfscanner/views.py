from django.shortcuts import render
from .models import newspaper
from .models import data
import pytesseract
from pdf2image import convert_from_path
from PIL import Image
from pathlib import Path
print(data)
# Create your views here.

def index(request):  

    dests=newspaper.objects.all()

    return render(request, 'index.html', {"dests": dests})

def news_data(request, pk):
    news_data = newspaper.objects.get(id=pk)
    pdf=news_data.pdf
    return render(request, 'news.html', {"news_data": news_data}) 

def num_news():
    news_data = data.objects.get(id=3)
    num_value=news_data.img_number+1
#    print(num_value+1)
    firstpage="static/images/firstpage/"+ str(num_value) +'.jpg'
    secondpage="/static/images/firstpage/"+ str(num_value) +'.jpg'
    data.objects.filter(id=3).update(img_number=num_value)
    return firstpage, secondpage

def scanning(request, lk):
    news_data = newspaper.objects.get(id=lk) 
    print("Optimization Started...")
    
    location=str(Path.cwd())+"\\media\\"
#    location1=str(Path.cwd())+"\\assets\\"
    
    pdf=location+str(news_data.pdf)
    pytesseract.pytesseract.tesseract_cmd = r'C:\Externalreq\Tesseract-OCR\tesseract.exe'
    data={}
    images = convert_from_path(pdf, 200, poppler_path=r'C:\Externalreq\poppler-23.08.0\Library\bin')
    print("There are ",len(images), "pages in this PDF")
    img=0
    firstpage=num_news()
    images[0].save(firstpage[0], 'JPEG')

    pages=[]
    for i in range(len(images)):   
        img=img+1         
        print(" Page", img, "scanning process started")
        #creating output spaces
        headings=[]
        articles=[]
        images[i].save('page'+ str(i) +'.jpg', 'JPEG')
        image = Image.open('page'+ str(i) +'.jpg')
        text = pytesseract.image_to_string(image)
        text1 = pytesseract.image_to_data(image, output_type='data.frame')
        text=((text.replace("\n\n","\t")).replace("\n","")).replace("\t","\n")
        data[i+1]=text.replace("-","")
        #print(data[i+1])
        #print(type(data[i+1]))
        c=data[i+1].splitlines()

        # Entering new column number 
        import numpy as np
        text1['number'] = np.arange(len(text1))
 

        # Separating big Headings
        heading=text1.loc[(text1.height >= 40) & (text1.text.notna())]

        # Creating lists of consicutive numbers from dataframe with greater than 3 consicutive numbers
        from itertools import groupby
        from operator import itemgetter
        newdata=heading['number'].to_list()
        const=[]
        for k, g in groupby(enumerate(newdata), lambda ix : ix[0] - ix[1]):
            cons=list(map(itemgetter(1), g))
            if len(cons)>=3:
                const.append(cons)
        #print(const)

        # Heading keywords appending and creating final output
        new=[]
        for i in range(len(const)):
            b=""
            for j in const[i]:
                a=heading.loc[(heading.number == j),["text"]]
                a=a.values[0][0]
                b+=a+" "
            new.append(b)
        #print(len(new))
        #print(new)

        # Work of Headings
        lis=[]
        count=0
        for i in range(len(new)):
            for j in range(len(c)):
                if new[i][:-2] in c[j]:
                    count+=1
                    #print(new[i],"========",c[j])
                    temp=c[j]
                    lis.append(j)
                    c[j]="heading"+str(count)
                    headings.append(temp)
                    break
                #else:
                    #print("NO", i, "======", j)
                    #print(new[i],"========",c[j])

        #print(c)
        #print(count, len(new), len(headings))

        # Work of Articles 
        count1=0
        print(len(lis), len(headings))
        for i in range(len(headings)-1):
            b=""
            small=lis[i]+1
            big=lis[i+1]
            for j in range(small, big):
                count1+=1
                b+=c[j]
                c[j]="Article"+str(count1)
            articles.append(b)
        if len(headings)>0:
            b=""
            small=lis[i]+1
            big=len(c)
            for j in range(small, big):
                count1+=1
                b+=c[j]
                c[j]="Article"+str(count1)
            articles.append(b)
        print(len(headings), len(articles))
        output=dict(zip(headings, articles))

    #open and read the file after the appending:
        pages.append(output)
    img1=firstpage[1]
    print("Page", img, "scanning process finished successfully")
    f = open("demofile2.txt", "a")
    f.write(str(headings))
    g = open("demofile3.txt", "a")
    g.write(str(articles))
    g.close()
    h=open("demofile4.txt", "a")
    h.write(str(output))
    h.close

    f.close()
    # img1="firstpage\\"+str(lk)+'page'+ str(0)+".jpg"
    newspaper.objects.filter(id=lk).update(dataloc=str(pages))
    newspaper.objects.filter(id=lk).update(scanned=True)
    newspaper.objects.filter(id=lk).update(imgloc=img1)
        

    return render(request, 'scanning.html', {"news_data": news_data})



def analysis(request, lk):
    key1=request.GET.get('key1')
    key2=request.GET.get('key2')
    key3=request.GET.get('key3')
    news_data = newspaper.objects.get(id=lk) 
    data=eval(news_data.dataloc)
    print(len(data))
    a=[]  
    b=str(key1)+" "+str(key2)+" "+str(key3)
    b=b.split(" ")
    print(b)
    for j in range(len(data)):
        lis=list(data[j].keys())
        for i in range(len(data[j])):
            if b[0] in data[j][lis[i]] and b[1] in data[j][lis[i]] and b[2] in data[j][lis[i]]:
                a.append([lis[i],i,j])
    
    while len(a)==0:
        print("No Articles found for these keywords. Enter another keywords")
        b=input("Enter 3 keywords : ").split(" ")
        print(b)
        for j in range(len(data)):
            lis=list(data[j].keys())
            for i in range(len(data[j])):
                if b[0] in data[j][lis[i]] and b[1] in data[j][lis[i]] and b[2] in data[j][lis[i]]:
                    a.append([lis[i],i,j])

    else:
        print("+++++++++++++++++")
        for i in range(len(a)):
            print("+++++++++++++++++")
            print(i+1, " ",a[i][0])
        print("+++++++++++++++++")
        print("+++++++++++++++++")
        c=int(input("Enter a number for heading : "))-1
        while c<0 or c>len(a):
            print("Enter a correct number : ")
            c=int(input("Enter a number for heading : "))-1


        #print(f'''====================================
        #====================================
        #====================================
        #{a[c][0]}
        #====================================
        #====================================
        #====================================
        #{data[a[c][2]][a[c][0]]}
        #=======s=============================''')

        final=data[a[c][2]][a[c][0]]
        #from transformers import pipeline
        #sentiment_pipeline = pipeline("sentiment-analysis")
        #print(sentiment_pipeline(final[0].split()))
        from vaderSentiment.vaderSentiment import SentimentIntensityAnalyzer
        analyzer= SentimentIntensityAnalyzer()

        analysed=analyzer.polarity_scores(final)
        #print(analysed,"++++++++++++++++++++++",final,,a[c][0])
    return render(request, 'analyse.html', {"analysed":str(analysed)})