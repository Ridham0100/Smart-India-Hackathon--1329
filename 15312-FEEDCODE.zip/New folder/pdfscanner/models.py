from django.db import models
import datetime
# Create your models here.


class newspaper(models.Model):
    name = models.CharField(max_length=255)
    pdf = models.FileField(upload_to="pdfs")
    desc = models.TextField(max_length=255)
    date = models.DateField(default=datetime.datetime.now)
    scanned = models.BooleanField(default=False)
    dataloc = models.TextField(max_length=None)
    imgloc = models.TextField(max_length=None)

class data(models.Model):
    img_number= models.IntegerField()
