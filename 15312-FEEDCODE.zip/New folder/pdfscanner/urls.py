from django.urls import path
from . import views

urlpatterns = [
    path("", views.index, name="index"),
    path("record/<int:pk>", views.news_data , name="record"),
    path("scanning/<str:lk>", views.scanning , name="scanning"),
    path("analysis/<str:lk>", views.analysis , name="analysis"),
]